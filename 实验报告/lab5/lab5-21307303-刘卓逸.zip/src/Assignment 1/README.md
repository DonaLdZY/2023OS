# 编译
```shell
cd build
make complie
make build
```
或者可以合起来
```shell
cd build
make complie && make build
```

# 运行
使用`run/bochsrc.bxrc`来运行。